"""
Customization layer for StyleBlend.

IDM-VTON (cuuupid/idm-vton on Replicate) only accepts: person photo, garment photo,
garment text description, category, steps, seed and crop. It has no inputs for colour,
size, fit, length, height or measurements, so those UI controls can only change the
final picture if we edit the picture ourselves.

This module does that. It works on the *base* try-on result and a garment mask:

  1. derive_garment_mask()  - finds the pixels that belong to the garment
  2. resolve_params()       - turns UI settings + profile data into concrete numbers
  3. render_customization() - recolours / resizes / re-lengths the garment region and
                              applies image finishing (brightness, contrast, ...)

Everything is deterministic, runs on CPU in well under a second, and never calls the
model again - so sliders can update the picture live after one generation.

HONEST LIMITS: these are image-space edits, not a new diffusion pass. Large size or
length changes will look best within the clamped ranges below.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np
from PIL import Image

SIZE_ORDER = ["XS", "S", "M", "L", "XL", "XXL"]
SIZE_WIDTH = {"XS": 0.90, "S": 0.95, "M": 1.00, "L": 1.05, "XL": 1.10, "XXL": 1.15}
FIT_WIDTH = {"slim": 0.94, "regular": 1.00, "relaxed": 1.07, "oversized": 1.15}
FIT_LENGTH = {"slim": 1.00, "regular": 1.00, "relaxed": 1.00, "oversized": 1.04}

WIDTH_MIN, WIDTH_MAX = 0.85, 1.25
LENGTH_MIN, LENGTH_MAX = 0.85, 1.15
REFERENCE_HEIGHT_CM = 172.0

# Body-measurement (cm) -> size label thresholds (upper bound exclusive).
_CHEST_BANDS = [(88, "XS"), (94, "S"), (102, "M"), (110, "L"), (118, "XL")]
_WAIST_BANDS = [(70, "XS"), (77, "S"), (85, "M"), (93, "L"), (101, "XL")]

HEX_RE = re.compile(r"^#?([0-9a-fA-F]{6})$")
JOB_ID_RE = re.compile(r"^req_[0-9a-f]{8}$")


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

def _clamp(v: Any, lo: float, hi: float, default: float = 0.0) -> float:
    try:
        f = float(v)
    except (TypeError, ValueError):
        return default
    if f != f:  # NaN
        return default
    return max(lo, min(hi, f))


def _size_from_bands(value_cm: Optional[float], bands) -> Optional[str]:
    if value_cm is None or value_cm <= 0:
        return None
    for upper, label in bands:
        if value_cm < upper:
            return label
    return "XXL"


def _norm_size(s: Any) -> Optional[str]:
    if not s:
        return None
    s = str(s).strip().upper()
    return s if s in SIZE_WIDTH else None


def _hex_to_rgb(hex_str: str) -> Tuple[int, int, int]:
    m = HEX_RE.match(hex_str.strip())
    if not m:
        raise ValueError(f"Invalid colour '{hex_str}'")
    h = m.group(1)
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


# ---------------------------------------------------------------------------
# 1. Garment mask
# ---------------------------------------------------------------------------

def _largest_components(binary: np.ndarray, keep_ratio: float = 0.15) -> np.ndarray:
    """Keep the largest blob plus any blob that is at least keep_ratio of its size."""
    n, labels, stats, _ = cv2.connectedComponentsWithStats(binary.astype(np.uint8), 8)
    if n <= 1:
        return binary
    areas = stats[1:, cv2.CC_STAT_AREA]
    biggest = areas.max()
    keep = np.zeros_like(binary, dtype=bool)
    for i, a in enumerate(areas, start=1):
        if a >= biggest * keep_ratio:
            keep |= labels == i
    return keep


def _skin_probability(rgb: np.ndarray) -> np.ndarray:
    ycrcb = cv2.cvtColor(rgb, cv2.COLOR_RGB2YCrCb)
    cr, cb = ycrcb[..., 1], ycrcb[..., 2]
    return ((cr >= 135) & (cr <= 173) & (cb >= 77) & (cb <= 127)).astype(np.float32)


def derive_garment_mask(
    person_path: str,
    result_path: str,
    masked_path: Optional[str] = None,
    cropped: bool = False,
) -> Optional[np.ndarray]:
    """
    Returns a float32 mask in [0,1] (H x W, same size as the result) or None if the
    garment region cannot be isolated reliably.

    Signals used:
      * IDM-VTON's masked output paints the editable area flat grey (~128). That area
        is where the new garment was synthesised.
      * |result - person| is large wherever the garment actually changed the photo
        (only comparable when the model did not auto-crop).
    """
    result = np.array(Image.open(result_path).convert("RGB"))
    h, w = result.shape[:2]

    grey_zone = None
    if masked_path and os.path.isfile(masked_path):
        masked = Image.open(masked_path).convert("RGB")
        if masked.size != (w, h):
            masked = masked.resize((w, h), Image.NEAREST)
        m = np.array(masked).astype(np.int16)
        grey_zone = (np.abs(m - 128) <= 6).all(axis=2)
        # The "masked" file is sometimes just a copy of the result: reject if the grey
        # area is implausibly tiny or covers almost everything.
        frac = grey_zone.mean()
        if frac < 0.02 or frac > 0.70:
            grey_zone = None

    diff_zone = None
    if not cropped and os.path.isfile(person_path):
        person = Image.open(person_path).convert("RGB").resize((w, h), Image.LANCZOS)
        d = np.abs(result.astype(np.int16) - np.array(person).astype(np.int16)).max(axis=2)
        d = cv2.GaussianBlur(d.astype(np.float32), (0, 0), 3)
        diff_zone = d > 18

    if grey_zone is not None and diff_zone is not None:
        binary = grey_zone & cv2.dilate(diff_zone.astype(np.uint8), np.ones((9, 9), np.uint8)).astype(bool)
        if binary.mean() < 0.01:  # intersection collapsed; trust the grey zone alone
            binary = grey_zone
    elif grey_zone is not None:
        binary = grey_zone
    elif diff_zone is not None:
        binary = diff_zone
    else:
        return None

    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    binary = cv2.morphologyEx(binary.astype(np.uint8), cv2.MORPH_OPEN, k)
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15)))
    binary = _largest_components(binary.astype(bool))

    # Drop exposed skin (arms, neck) unless the garment itself is skin-coloured.
    skin = _skin_probability(result)
    if binary.any():
        garment_skin_share = skin[binary].mean()
        if garment_skin_share < 0.5:
            skin_clean = cv2.morphologyEx(skin.astype(np.uint8), cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
            binary = binary & ~skin_clean.astype(bool)
            binary = cv2.morphologyEx(binary.astype(np.uint8), cv2.MORPH_OPEN, k).astype(bool)

    coverage = binary.mean()
    if coverage < 0.015 or coverage > 0.70:
        return None

    binary = cv2.erode(binary.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)  # avoid edge halos
    soft = cv2.GaussianBlur(binary.astype(np.float32), (0, 0), 1.6)
    return np.clip(soft, 0.0, 1.0)


# ---------------------------------------------------------------------------
# 2. Parameter resolution
# ---------------------------------------------------------------------------

def default_customization() -> Dict[str, Any]:
    return {
        "color": {"hex": None, "strength": 100},
        "fit": "regular",
        "garment_size": None,
        "length": 0,
        "use_profile": False,
        "profile": {},
        "adjust": {
            "brightness": 0, "contrast": 0, "saturation": 0,
            "warmth": 0, "sharpness": 0, "scope": "garment",
        },
    }


def resolve_params(raw: Optional[Dict[str, Any]], category: str = "upper_body") -> Dict[str, Any]:
    """
    Validates & clamps a customization dict and computes the effective geometry.
    Returns a dict containing the cleaned params plus 'sx', 'sy' and 'summary'.
    """
    base = default_customization()
    raw = raw or {}

    color_raw = raw.get("color") or {}
    hex_val = color_raw.get("hex")
    if hex_val:
        if not HEX_RE.match(str(hex_val).strip()):
            raise ValueError(f"Invalid colour '{hex_val}'. Use a hex value like #C0392B.")
        hex_val = "#" + HEX_RE.match(str(hex_val).strip()).group(1).upper()
    else:
        hex_val = None
    color = {"hex": hex_val, "strength": _clamp(color_raw.get("strength", 100), 0, 100, 100)}

    fit = str(raw.get("fit") or "regular").lower()
    if fit not in FIT_WIDTH:
        raise ValueError(f"Invalid fit '{fit}'. Allowed: {', '.join(FIT_WIDTH)}.")

    garment_size = _norm_size(raw.get("garment_size"))
    length = _clamp(raw.get("length", 0), -15, 15, 0)

    adj_raw = raw.get("adjust") or {}
    scope = str(adj_raw.get("scope") or "garment").lower()
    if scope not in ("garment", "image"):
        scope = "garment"
    adjust = {
        "brightness": _clamp(adj_raw.get("brightness", 0), -50, 50),
        "contrast": _clamp(adj_raw.get("contrast", 0), -50, 50),
        "saturation": _clamp(adj_raw.get("saturation", 0), -100, 100),
        "warmth": _clamp(adj_raw.get("warmth", 0), -50, 50),
        "sharpness": _clamp(adj_raw.get("sharpness", 0), 0, 100),
        "scope": scope,
    }

    use_profile = bool(raw.get("use_profile", False))
    prof_raw = raw.get("profile") or {}
    profile = {
        "height_cm": _clamp(prof_raw.get("height_cm", 0), 0, 260, 0) or None,
        "chest_cm": _clamp(prof_raw.get("chest_cm", 0), 0, 250, 0) or None,
        "waist_cm": _clamp(prof_raw.get("waist_cm", 0), 0, 250, 0) or None,
        "hip_cm": _clamp(prof_raw.get("hip_cm", 0), 0, 250, 0) or None,
        "preferred_size": _norm_size(prof_raw.get("preferred_size")),
    }

    summary: List[str] = []

    # --- body size (the size this person actually is) -------------------------
    body_size = None
    body_src = ""
    if use_profile:
        if category == "lower_body":
            body_size = _size_from_bands(profile["waist_cm"], _WAIST_BANDS)
            body_src = f"waist {profile['waist_cm']:g} cm" if body_size else ""
        else:
            body_size = _size_from_bands(profile["chest_cm"], _CHEST_BANDS)
            body_src = f"chest {profile['chest_cm']:g} cm" if body_size else ""
        if body_size is None and profile["preferred_size"]:
            body_size, body_src = profile["preferred_size"], "preferred size"
    if body_size is None:
        body_size = "M"
        body_src = "default M"

    # --- width ----------------------------------------------------------------
    size_ratio = 1.0
    if garment_size:
        size_ratio = SIZE_WIDTH[garment_size] / SIZE_WIDTH[body_size]
        if abs(size_ratio - 1.0) > 0.001:
            summary.append(f"Size {garment_size} garment on {body_size} body ({body_src}): width ×{size_ratio:.2f}")
    sx = size_ratio * FIT_WIDTH[fit]
    if fit != "regular":
        summary.append(f"{fit.capitalize()} fit: width ×{FIT_WIDTH[fit]:.2f}")
    sx = max(WIDTH_MIN, min(WIDTH_MAX, sx))

    # --- length ---------------------------------------------------------------
    height_factor = 1.0
    if use_profile and profile["height_cm"]:
        height_factor = max(0.92, min(1.08, REFERENCE_HEIGHT_CM / profile["height_cm"]))
        if abs(height_factor - 1.0) > 0.002:
            summary.append(f"Height {profile['height_cm']:g} cm: length ×{height_factor:.2f}")
    sy = (1.0 + length / 100.0) * height_factor * FIT_LENGTH[fit]
    if length:
        summary.append(f"Length {length:+g}%")
    sy = max(LENGTH_MIN, min(LENGTH_MAX, sy))

    if color["hex"]:
        summary.append(f"Colour {color['hex']} at {color['strength']:g}%")
    for key, label in (("brightness", "Brightness"), ("contrast", "Contrast"),
                       ("saturation", "Saturation"), ("warmth", "Warmth"),
                       ("sharpness", "Sharpness")):
        if adjust[key]:
            summary.append(f"{label} {adjust[key]:+g} ({adjust['scope']})")

    cleaned = {
        "color": color, "fit": fit, "garment_size": garment_size, "length": length,
        "use_profile": use_profile, "profile": profile, "adjust": adjust,
    }
    return {
        "params": cleaned,
        "sx": round(sx, 4),
        "sy": round(sy, 4),
        "body_size": body_size,
        "summary": summary,
        "is_noop": (not summary),
        "needs_mask": bool(color["hex"] or abs(sx - 1) > 0.004 or abs(sy - 1) > 0.004
                           or (adjust["scope"] == "garment" and any(
                               adjust[k] for k in ("brightness", "contrast", "saturation", "warmth", "sharpness")))),
    }


def customization_digest(resolved: Dict[str, Any]) -> str:
    blob = json.dumps(resolved["params"], sort_keys=True, default=str)
    return hashlib.sha1(blob.encode()).hexdigest()[:10]


# ---------------------------------------------------------------------------
# 3. Rendering
# ---------------------------------------------------------------------------

def _warp_garment(img: np.ndarray, mask: np.ndarray, sx: float, sy: float) -> Tuple[np.ndarray, np.ndarray]:
    """Scale the garment layer about its horizontal centre / top edge and composite."""
    h, w = mask.shape
    ys, xs = np.nonzero(mask > 0.5)
    if len(xs) == 0:
        return img, mask
    cx = float(xs.mean())
    top = float(ys.min())
    # anchor slightly below the top edge so shoulders / waistband stay put
    y0 = top + 0.05 * (ys.max() - top)

    gx, gy = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    map_x = (cx + (gx - cx) / sx).astype(np.float32)
    map_y = (y0 + (gy - y0) / sy).astype(np.float32)

    layer = (img.astype(np.float32) * mask[..., None])
    layer_w = cv2.remap(layer, map_x, map_y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
    mask_w = cv2.remap(mask.astype(np.float32), map_x, map_y, cv2.INTER_LINEAR,
                       borderMode=cv2.BORDER_CONSTANT, borderValue=0)
    mask_w = np.clip(mask_w, 0, 1)

    # Fill whatever the garment used to cover but no longer does. Inpaint the WHOLE old
    # garment region from pixels outside it (background / skin / other clothing) so dark
    # garment edges never smear into the exposed strips; the new garment is drawn on top.
    exposed = np.clip(mask - mask_w, 0, 1)
    base = img
    if (exposed > 0.08).any():
        unknown = cv2.dilate((mask > 0.03).astype(np.uint8), np.ones((9, 9), np.uint8))
        base = cv2.inpaint(img, unknown * 255, 8, cv2.INPAINT_TELEA)

    out = base.astype(np.float32) * (1 - mask_w[..., None]) + layer_w
    return np.clip(out, 0, 255).astype(np.uint8), mask_w


def _colorize(img: np.ndarray, mask: np.ndarray, hex_color: str, strength: float) -> np.ndarray:
    r, g, b = _hex_to_rgb(hex_color)
    t_hsv = cv2.cvtColor(np.array([[[r, g, b]]], dtype=np.uint8), cv2.COLOR_RGB2HSV)[0, 0].astype(np.float32)
    t_h, t_s, t_v = t_hsv[0], t_hsv[1] / 255.0, t_hsv[2] / 255.0

    hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV).astype(np.float32)
    v = hsv[..., 2] / 255.0
    s = hsv[..., 1] / 255.0

    sel = mask > 0.5
    med_v = float(np.median(v[sel])) if sel.any() else 0.5

    # Preserve shading (folds, shadows) but move the garment's overall brightness to the
    # target's. Black tees become dark-but-visibly-coloured, white tees take on the tint.
    target_v = float(np.clip(t_v, 0.18, 0.95))
    ratio = (v + 0.05) / (med_v + 0.05)          # +0.05 damps sensor/JPEG noise in dark fabric
    v_new = np.clip(target_v * np.power(ratio, 0.6), 0, 1)

    s_new = np.full_like(s, t_s)
    s_new = s_new * (1.0 - 0.55 * np.clip((v_new - 0.85) / 0.15, 0, 1))  # keep highlights bright

    out_hsv = np.stack([np.full_like(v, t_h), s_new * 255.0, v_new * 255.0], axis=-1)
    recol = cv2.cvtColor(np.clip(out_hsv, 0, 255).astype(np.uint8), cv2.COLOR_HSV2RGB)

    # Keep prints / logos / trims: pixels whose colour is far from the garment's base fabric
    # colour are only lightly recoloured.
    lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB).astype(np.float32)
    base_lab = np.median(lab[sel], axis=0) if sel.any() else lab.reshape(-1, 3).mean(axis=0)
    d = np.sqrt((0.6 * (lab[..., 0] - base_lab[0]) * 100.0 / 255.0) ** 2
                + (lab[..., 1] - base_lab[1]) ** 2 + (lab[..., 2] - base_lab[2]) ** 2)
    t = np.clip((d - 22.0) / 30.0, 0, 1)
    keep_print = t * t * (3 - 2 * t)  # smoothstep
    alpha = (mask * (strength / 100.0) * (1.0 - 0.9 * keep_print))[..., None]
    return np.clip(img.astype(np.float32) * (1 - alpha) + recol.astype(np.float32) * alpha, 0, 255).astype(np.uint8)


def _finish(img: np.ndarray, adj: Dict[str, Any]) -> np.ndarray:
    out = img.astype(np.float32)

    if adj["brightness"]:
        out *= 1.0 + adj["brightness"] / 100.0
    if adj["contrast"]:
        out = (out - 128.0) * (1.0 + adj["contrast"] / 100.0) + 128.0
    out = np.clip(out, 0, 255)

    if adj["saturation"]:
        hsv = cv2.cvtColor(out.astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)
        hsv[..., 1] = np.clip(hsv[..., 1] * (1.0 + adj["saturation"] / 100.0), 0, 255)
        out = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32)

    if adj["warmth"]:
        shift = adj["warmth"] * 0.4
        out[..., 0] += shift
        out[..., 2] -= shift
        out = np.clip(out, 0, 255)

    if adj["sharpness"]:
        amount = adj["sharpness"] / 100.0 * 1.6
        blur = cv2.GaussianBlur(out, (0, 0), 1.4)
        out = np.clip(out + (out - blur) * amount, 0, 255)

    return out.astype(np.uint8)


def render_customization(
    base_path: str,
    mask: Optional[np.ndarray],
    resolved: Dict[str, Any],
) -> Tuple[Image.Image, List[str], List[str]]:
    """
    Applies a resolved customization to the base result.
    Returns (image, applied_labels, warnings).
    """
    img = np.array(Image.open(base_path).convert("RGB"))
    p = resolved["params"]
    applied: List[str] = []
    warnings: List[str] = []

    if mask is not None and mask.shape != img.shape[:2]:
        mask = cv2.resize(mask, (img.shape[1], img.shape[0]), interpolation=cv2.INTER_LINEAR)

    garment_ops_requested = resolved["needs_mask"]
    if garment_ops_requested and mask is None:
        warnings.append(
            "The garment area could not be isolated in this result, so colour, fit and "
            "garment-only adjustments were skipped. Try again with a clearer full-body photo."
        )

    cur_mask = mask

    # 1. Geometry (size / fit / length)
    sx, sy = resolved["sx"], resolved["sy"]
    if cur_mask is not None and (abs(sx - 1) > 0.004 or abs(sy - 1) > 0.004):
        img, cur_mask = _warp_garment(img, cur_mask, sx, sy)
        applied.append(f"Fit: width ×{sx:.2f}, length ×{sy:.2f}")

    # 2. Colour
    if cur_mask is not None and p["color"]["hex"] and p["color"]["strength"] > 0:
        img = _colorize(img, cur_mask, p["color"]["hex"], p["color"]["strength"])
        applied.append(f"Colour {p['color']['hex']} ({p['color']['strength']:g}%)")

    # 3. Finishing
    adj = p["adjust"]
    if any(adj[k] for k in ("brightness", "contrast", "saturation", "warmth", "sharpness")):
        if adj["scope"] == "image":
            img = _finish(img, adj)
            applied.append("Finishing applied to whole image")
        elif cur_mask is not None:
            finished = _finish(img, adj)
            a = cur_mask[..., None]
            img = np.clip(img.astype(np.float32) * (1 - a) + finished.astype(np.float32) * a, 0, 255).astype(np.uint8)
            applied.append("Finishing applied to garment")

    return Image.fromarray(img), applied, warnings
